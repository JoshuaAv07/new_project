import react from "react";
import { Link } from "react-router-dom";
import "./character.css";

const Character = (props) => {
    return (
        <ReactFragment>
            <div className="Character_container">
                <Link className="">

                </Link>

            </div>
        </ReactFragment>
    )
}
